/* Global Variables */
const zipCode = document.getElementById('zip'); 
const feelings = document.getElementById('feelings');
const date = document.getElementById('date');
const temp = document.getElementById('temp');
const content= document.getElementById('content');
const GenButton = document.getElementById('generate');

// Personal API Key for OpenWeatherMap API
const apiKey = "&appid=62ed3beedc5315c73f9f9b20a5152cf8&units=metric";
const ServUrl = "http://localhost:4000/";
const Url = (`http://api.openweathermap.org/data/2.5/weather?zip=${zipCode.value}${apiKey}`);


//Get the date
let d = new Date();
let newDate = d.getMonth() + '.' + d.getDate() + '.' + d.getFullYear();


// Getting data
const GetData = async (link)=>{
    let request = await fetch(link);
    try {
        const source = await request.json();
        return source
    }
    catch(error) {
        console.log("Error found ! " , error)
    }
};

//Sending data
const SendData = async(link , info)=>{
    const res = await fetch (link , {
        method: 'POST', 
        credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(info)
      });

         try {
        const DataSent = await res.json();
        return DataSent;
      }catch(error) {
        console.log("error", error);
      }
  };

  // the updateUI function
  const updateUI = async (link) =>{
    let req
    try{
      req = await fetch(link);
    }catch(error) {
      console.log("error", error);
    }
    
    try {
      const DataInfo = await req.json();
      date.innerHTML = `Date: ${DataInfo.date}.`;
      temp.innerHTML = `Temperature: ${DataInfo.temp}° C.`;
      content.innerHTML = `User feedback: ${DataInfo.content}.`;
    }
    catch(error) {
      console.log("error", error);
    }
  };



GenButton.addEventListener('click' , ()=> {
  GetData(`http://api.openweathermap.org/data/2.5/weather?zip=${zipCode.value}${apiKey}`).then(function(source){
      SendData(`${ServUrl}postData` , {
          temp: source.main.temp,
          date:newDate,
          content:feelings.value
      })
      .then(function(){
          updateUI(`${ServUrl}All`);
      })
  })
});
