# Weather-Journal App Project

## Overview
A project for the udacity nanodegree related to the FWD program
I've created asynchronous web app that uses Web API and user data to dynamically update the UI. 

## Instructions
first of all we have to install nodeJs , then install the dependencies which is :=
-Express
-Body-Parser
-CORS

also i registered on openweathermap site and got my apikey to work with it
I used the skeleton project which was given to us from udacity and built my task on it
So i modified the server.js and initialized my server localhost , also modified the app.js file
i used index.html which helped me with the structure of the task and made some style on style.css file

So the data is fetched from the openweathermap API to the client-side
Then the data is sent to the server-side
Then it's sent to update the UI with it

